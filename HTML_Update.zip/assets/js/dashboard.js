$(function() {
  'use strict'

  var flotChart1Data = [
    [0,49.331065063219285],
    [1,48.79814898366035],
    [2,50.61793547911337],
    [3,53.31696317779434],
    [4,54.78560952831719],
    [5,53.84293992505776],
    [6,54.682958355082874],
    [7,56.742547193381654],
    [8,56.99677491680908],
    [9,56.144488388681445],
    [10,56.567122269843885],
    [11,60.355022877262684],
    [12,58.7457726121753],
    [13,61.445407102315514],
    [14,61.112870581452086],
    [15,58.57202276349258],
    [16,54.72497594269612],
    [17,52.070341498681124],
    [18,51.09867716530438],
    [19,47.48185519192089],
    [20,48.57861168097493],
    [21,48.99789250679436],
    [22,53.582491800119456],
    [23,50.28407438696142],
    [24,46.24606628705599],
    [25,48.614330310543856],
    [26,51.75313497797672],
    [27,51.34463925296746],
    [28,50.217320673443936],
    [29,54.657281647073304],
    [30,52.445057217757245],
    [31,53.063914668561345],
    [32,57.07494250387825],
    [33,52.970403392565515],
    [34,48.723854145068756],
    [35,52.69064629353968],
    [36,53.590890118378205],
    [37,58.52332126105745],
    [38,55.1037709679581],
    [39,58.05347017020425],
    [40,61.350810521199946],
    [41,57.746188675088575],
    [42,60.276910973029786],
    [43,61.00841651851749],
    [44,57.786733623457636],
    [45,56.805721677811356],
    [46,58.90301959619822],
    [47,62.45091969566289],
    [48,58.75007922945926],
    [49,58.405842466185355],
    [50,56.746633122658444],
    [51,52.76631598845634],
    [52,52.3020769891715],
    [53,50.56370473325533],
    [54,55.407205992344544],
    [55,55.49825590435839],
    [56,52.4975614755482],
    [57,48.79614749316488],
    [58,47.46776704767111],
    [59,43.317880548036456],
    [60,38.96296121124144],
    [61,34.73218432559628],
    [62,31.033700732272116],
    [63,32.637987000382296],
    [64,36.89513637594264],
    [65,35.89701755609185],
    [66,32.742284578187544],
    [67,33.20516407297906],
    [68,30.82094321791933],
    [69,28.64770271525896],
    [70,28.44679026902145],
    [71,43.737654438195236],
    [72,42.755190738237744],
    [73,41.96228929938593],
    [74,40.38197394166947],
    [75,70.95038772723346],
    [76,72.08944448751686],
    [77,64.54611335622507],
    [78,61.309610481106425],
    [79,65.276849322378055],
    [80,71.25409223418214],
    [81,73.920374921780102],
    [82,75.143447932376702],
    [83,69.09444253479626],
    [84,59.79459089729409],
    [85,55.46775072519832],
    [86,54.9908486073969],
    [87,56.218855925354447],
    [88,51.9163141686872],
    [89,44.217667423877607],
    [90,40.135179958932145],
    [91,39.08666008920407],
    [92,45.006269617032526],
    [93,34.201671310476282],
    [94,37.475865090236113],
    [95,32.645754524211824],
    [96,30.76161040821357],
    [97,29.995208323029495],
    [98,31.59338056489445],
    [99,40.536707176236195],
    [100,41.01308268888571],
    [101,38.957161242832626],
    [102,37.237091619700053],
    [103,35.10178875669874],
    [104,39.634765519499563],
    [105,45.064946755449817],
    [106,35.370593801826132],
    [107,31.321453557866203],
    [108,34.947464543531186],
    [109,32.750516645477425],
    [110,48.382042945356737],
    [111,41.569147793065632],
    [112,45.949159188821604],
    [113,42.965876707018058],
    [114,41.359355082317443],
    [115,44.163139419453657],
    [116,48.106761506858124],
    [117,39.843319717588216],
    [118,37.24291158460492],
    [119,35.799018581487058],
    [120,32.038359368301329],
  ];

  // Dashbaord date start
  if($('#dashboardDate').length) {
    var date = new Date();
    var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    $('#dashboardDate').datepicker({
      format: "dd-MM-yyyy",
      todayHighlight: true,
      autoclose: true
    });
    $('#dashboardDate').datepicker('setDate', today);
  }
  // Dashbaord date end

  // Flot chart1 start
  if($('#flotChart1').length) {
    $.plot('#flotChart1', [{
      data: flotChart1Data,
      color: '#727cf5'
      }], {
      series: {
        shadowSize: 0,
        lines: {
          show: true,
          lineWidth: 2,
          fill: true,
          fillColor: 'transparent'
        }
      },
      grid: {
        borderColor: 'transparent',
        borderWidth: 1,
        labelMargin: 0,
        aboveData: false
      },
      yaxis: {
        show: true,
        color: 'rgba(0,0,0,0.06)',
        ticks: [[0, ''], [15, '1000'], [30, '2000'], [45, '3000'], [60, '4000'], [75, '5000']],
        tickColor: gridLineColor,
        min: 0,
        max: 80,
        font: {
          size: 11,
          weight: '600',
          color: colors.muted
        }
      },
      xaxis: {
        show: true,
        color: 'rgba(0,0,0,0.1)',
        ticks: [[0, 'Mon'], [20, 'Tue'], [40, 'Wen'], [60, 'Thu'], [80, 'Fri'], [100, 'Sat'], [120, 'Sun']],
        tickColor: gridLineColor,      
        font: {
          size: 13,
          color: colors.muted
        },
        reserveSpace: false
      }
    });
  }
  // Flot chart1 end

  // Apex chart1 start
  if($('#apexChart1').length) {
    var options1 = {
      chart: {
        type: "line",
        height: 60,
        sparkline: {
          enabled: !0
        }
      },
      series: [{
          data: [3844, 3855, 3841, 3867, 3822, 3843, 3821, 3841, 3856, 3827, 3843]
      }],
      stroke: {
        width: 2,
        curve: "smooth"
      },
      markers: {
        size: 0
      },
      colors: ["#727cf5"],
      tooltip: {
        fixed: {
          enabled: !1
        },
        x: {
          show: !1
        },
        y: {
          title: {
            formatter: function(e) {
              return ""
            }
          }
        },
        marker: {
          show: !1
        }
      }
    };
    new ApexCharts(document.querySelector("#apexChart1"),options1).render();
  }
  // Apex chart1 end

  // Apex chart2 start
  if($('#apexChart2').length) {
    var options2 = {
      chart: {
        type: "bar",
        height: 60,
        sparkline: {
          enabled: !0
        }
      },
      plotOptions: {
        bar: {
          columnWidth: "60%"
        }
      },
      colors: ["#727cf5"],
      series: [{
        data: [36, 77, 52, 90, 74, 35, 55, 23, 47, 10, 63]
      }],
      labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
      xaxis: {
        crosshairs: {
          width: 1
        }
      },
      tooltip: {
        fixed: {
          enabled: !1
        },
        x: {
          show: !1
        },
        y: {
          title: {
            formatter: function(e) {
              return ""
            }
          }
        },
        marker: {
          show: !1
        }
      }
    };
    new ApexCharts(document.querySelector("#apexChart2"),options2).render();
  }
  // Apex chart2 end

  // Apex chart3 start
  if($('#apexChart3').length) {
    var options3 = {
      chart: {
        type: "line",
        height: 60,
        sparkline: {
          enabled: !0
        }
      },
      series: [{
          data: [41, 45, 44, 46, 52, 54, 43, 74, 82, 82, 89]
      }],
      stroke: {
        width: 2,
        curve: "smooth"
      },
      markers: {
        size: 0
      },
      colors: ["#727cf5"],
      tooltip: {
        fixed: {
          enabled: !1
        },
        x: {
          show: !1
        },
        y: {
          title: {
            formatter: function(e) {
              return ""
            }
          }
        },
        marker: {
          show: !1
        }
      }
    };
    new ApexCharts(document.querySelector("#apexChart3"),options3).render();
  }
  // Apex chart3 end


  // Progressgar1 start

  // Monthly sales chart start
  if($('#monthly-sales-chart').length) {
    var monthlySalesChart = document.getElementById('monthly-sales-chart').getContext('2d');
      new Chart(monthlySalesChart, {
        type: 'bar',
        data: {
          labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
          datasets: [{
            label: 'Sales',
            data: [150,110,90,115,125,160,190,140,100,110,120,120],
            backgroundColor: colors.primary
          }]
        },
        options: {
          maintainAspectRatio: false,
          legend: {
            display: false,
              labels: {
                display: false
              }
          },
          scales: {
            xAxes: [{
              display: true,
              barPercentage: .3,
              categoryPercentage: .6,
              gridLines: {
                display: false
              },
              ticks: {
                fontColor: '#8392a5',
                fontSize: 10
              }
            }],
            yAxes: [{
              gridLines: {
                color: gridLineColor
              },
              ticks: {
                fontColor: '#8392a5',
                fontSize: 10,
                min: 80,
                max: 200
              }
            }]
          }
        }
      }
    );
  }
  // Monthly sales chart end

});